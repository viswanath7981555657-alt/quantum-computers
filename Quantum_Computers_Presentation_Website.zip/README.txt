# Quantum Computers Presentation Website

Open `index.html` in Chrome/Edge/Firefox. No installation or internet connection is required.

Features:
- Presentation-style quantum computing introduction
- Classical vs quantum comparison
- Qubit and superposition explanation
- Interactive X/H/Z gate demo
- Quantum circuit visualization
- Applications and limitations
- Presentation Mode / fullscreen
- Responsive design for desktop and mobile

Created for: Quantum Boys
